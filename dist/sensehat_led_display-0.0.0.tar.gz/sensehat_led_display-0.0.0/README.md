# sensehat_led_display
RaspberryPi mounted SenseHat's 8x8 led display function as Python object
